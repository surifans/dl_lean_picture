* Renamed `Augmenter.reseed()` to `Augmenter.seed_()`. #444
* Renamed `Augmenter.remove_augmenters_inplace()` to
  `Augmenter.remove_augmenters_()`. #444