# Unified OpenCV Input Normalization #565

* Refactored various augmenters to use the same normalization for OpenCV
  inputs. This probably fixes some previously undiscovered bugs.
