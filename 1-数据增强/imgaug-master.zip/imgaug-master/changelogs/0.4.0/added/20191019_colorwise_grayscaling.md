# Added `RemoveSaturation` #462

* Added `RemoveSaturation`, a shortcut for `MultiplySaturation((0.0, 1.0))`
  with outputs similar to `Grayscale((0.0, 1.0))`.
