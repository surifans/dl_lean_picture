# Multi-Channel cvals in `pad()` #502

Improved `imgaug.augmenters.size.pad()` to support multi-channel values
for the `cval` parameter (e.g. RGB colors).
