# Added `round` Parameter to `Discretize` #553

Added the parameter `round` to `imgaug.parameters.Discretize`. The parameter
defaults to `True`, i.e. the default behaviour of `Discretize` did not change.
