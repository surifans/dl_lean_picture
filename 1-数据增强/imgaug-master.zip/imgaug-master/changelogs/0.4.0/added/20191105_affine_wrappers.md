# Added Wrappers around `Affine` #484

* Added `imgaug.augmenters.geometric.ScaleX`.
* Added `imgaug.augmenters.geometric.ScaleY`.
* Added `imgaug.augmenters.geometric.TranslateX`.
* Added `imgaug.augmenters.geometric.TranslateY`.
* Added `imgaug.augmenters.geometric.Rotate`.
* Added `imgaug.augmenters.geometric.ShearX`.
* Added `imgaug.augmenters.geometric.ShearY`.
