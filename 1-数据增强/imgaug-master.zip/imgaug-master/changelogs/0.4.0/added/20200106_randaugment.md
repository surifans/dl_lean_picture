# Add RandAugment #553

Added a RandAugment augmenter, similar to the one described in the paper
"RandAugment: Practical automated data augmentation with a reduced
search space".

* Added module `imgaug.augmenters.collections`
* Added augmenter `imgaug.augmenters.collections.RandAugment`.
