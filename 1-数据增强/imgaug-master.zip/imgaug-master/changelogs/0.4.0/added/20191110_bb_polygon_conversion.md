# Bounding Box to Polygon Conversion #489

* Added method `imgaug.augmentables.bbs.BoundingBox.to_polygon()`.
* Added method
  `imgaug.augmentables.bbs.BoundingBoxesOnImage.to_polygons_on_image()`.
