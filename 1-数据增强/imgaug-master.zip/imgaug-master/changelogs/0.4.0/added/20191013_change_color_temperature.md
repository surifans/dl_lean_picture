# New Augmenter ChangeColorTemperature #454

* Added augmenter `imgaug.augmenters.color.ChangeColorTemperature`.
* Added function `imgaug.augmenters.color.change_color_temperatures_()`.
* Added function `imgaug.augmenters.color.change_color_temperature_()`.
