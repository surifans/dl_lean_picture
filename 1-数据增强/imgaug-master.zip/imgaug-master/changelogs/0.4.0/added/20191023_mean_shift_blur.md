# Added Augmenter `MeanShiftBlur` #466

* Added function `imgaug.augmenters.blur.blur_mean_shift_(image)`.
* Added augmenter `imgaug.augmenters.blur.MeanShiftBlur`.
