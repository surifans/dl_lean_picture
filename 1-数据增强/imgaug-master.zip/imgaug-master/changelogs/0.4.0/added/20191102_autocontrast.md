# Autocontrast #479

* Added `imgaug.augmenters.pillike.autocontrast()`, a function with identical
  inputs and outputs to `PIL.ImageOps.autocontrast`.
* Added `imgaug.augmenters.pillike.Autocontrast`.
