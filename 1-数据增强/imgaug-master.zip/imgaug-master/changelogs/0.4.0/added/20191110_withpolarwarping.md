# Added `WithPolarWarping` #489

* Added augmenter `imgaug.augmenters.geometric.WithPolarWarping`, an
  augmenter that applies child augmenters in a polar representation of the
  image.
