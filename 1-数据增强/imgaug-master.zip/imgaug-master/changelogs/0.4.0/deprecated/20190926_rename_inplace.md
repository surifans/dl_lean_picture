* Deprecated method `Augmenter.reseed()`.
  Use `Augmenter.seed_()` instead. #444
* Deprecated method `Augmenter.remove_augmenters_inplace()`.
  Use `Augmenter.remove_augmenters_()` instead. #444