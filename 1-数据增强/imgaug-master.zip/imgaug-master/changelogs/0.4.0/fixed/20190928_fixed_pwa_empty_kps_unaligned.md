* Fixed keypoint augmentation in `PiecewiseAffine` potentially being
  unaligned if a `KeypointsOnImage` instance contained no keypoints. #446
