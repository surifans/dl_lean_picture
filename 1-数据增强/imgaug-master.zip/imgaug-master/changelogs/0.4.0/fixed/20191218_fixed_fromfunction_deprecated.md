# Fixed `scipy.fromfunction` Deprecated #529

* Fixed deprecated `scipy.fromfunction()` being called.
