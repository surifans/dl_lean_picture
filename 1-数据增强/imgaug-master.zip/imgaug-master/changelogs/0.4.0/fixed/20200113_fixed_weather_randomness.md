* Fixed some augmenters in module `weather` not transferring seed values
  or random states that were provided upon creation to child augmenters. #568
