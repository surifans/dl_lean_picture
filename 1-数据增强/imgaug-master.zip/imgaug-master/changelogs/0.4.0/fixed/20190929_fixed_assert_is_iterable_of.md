* Fixed `imgaug.validation.assert_is_iterable_of()` producing a not
  well-designed error if the input was not an iterable. #446
