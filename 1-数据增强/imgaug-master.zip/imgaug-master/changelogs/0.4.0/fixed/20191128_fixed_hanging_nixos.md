# Fixed Hanging Code in NixOS #414 #510

* Fixed code hanging indefinitely when using multicore augmentation
  on NixOS.