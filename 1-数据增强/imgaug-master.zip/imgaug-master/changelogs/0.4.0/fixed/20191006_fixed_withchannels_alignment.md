* Fixed a problem in `WithChannels` that could lead random sampling in child
  augmenters being unaligned between images and corresponding non-image
  data. #451