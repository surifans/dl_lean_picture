* Fixed typo in image normalization. #451
