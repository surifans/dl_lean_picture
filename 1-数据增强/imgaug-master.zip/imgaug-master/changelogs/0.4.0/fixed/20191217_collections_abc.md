# Fixed Abstract Base Classes Import #527

* Fixed a deprecation warning and potential crash in python 3.8
  related to the use of `collections` instead of `collections.abc`.
