* Fixed `imgaug.validation.convert_iterable_to_string_of_types()` crashing due
  to not converting types to strings before joining them. #446