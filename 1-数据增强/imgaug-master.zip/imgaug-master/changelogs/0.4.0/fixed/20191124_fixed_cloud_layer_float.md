* Fixed `CloudLayer.draw_on_image()` producing tuples instead of arrays
  as output for `float` input images. #540