- A problem was fixed that led to `blend_alpha()`
  always producing assertion errors if the dtype
  `float128` was not available on the given
  system. #678
