* Fixed a broken `imageio` dependency. The package no longer
  supports python 3.4 and earlier and will fail to install in the
  latest version. The dependency is now set to be more
  restrictive for older python versions. #627 #628
