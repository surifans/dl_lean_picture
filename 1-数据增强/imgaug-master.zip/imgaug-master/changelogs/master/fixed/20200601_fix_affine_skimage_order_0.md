- Fixed a deprecation warning in `Affine` that would
  be caused when providing boolean images and
  `order != 0`. #685
