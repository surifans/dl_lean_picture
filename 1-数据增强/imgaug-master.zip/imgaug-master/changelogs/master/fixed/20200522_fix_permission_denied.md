- Fixed a `permission denied` error when calling
  `StochasticParameter.draw_distribution_graph()` in
  Windows. #678
