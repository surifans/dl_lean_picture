* Fixed `change_color_temperatures_()` crashing on batches
  that did not contain exactly `1` or `3` images. #646 #650
