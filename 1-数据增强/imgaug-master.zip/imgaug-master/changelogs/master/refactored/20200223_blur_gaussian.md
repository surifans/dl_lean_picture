# Refactored `blur_gaussian_()` #626

This patch cleans up the code of
`imgaug.augmenters.blur.blur_gaussian_()`. A very small
performance improvement (factor ~1.03x) is expected.
