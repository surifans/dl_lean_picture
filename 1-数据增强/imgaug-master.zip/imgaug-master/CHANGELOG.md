This file is no longer used.
See `changelogs/` for all current and previous changelogs.
