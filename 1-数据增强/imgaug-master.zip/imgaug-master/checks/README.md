These are checks for the library.
In contrast to tests they are expected to be executed by hand.
Their results have to be manually investigated (usually by looking at images).
